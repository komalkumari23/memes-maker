import React from 'react';

export default function Navbar() {
	return <div className='Navigation-Wrapper'>Memes Maker</div>;
}
