import React,{useState} from "react";
import { HexColorPicker } from "react-colorful";
import { getFormat } from "colord";

export default function Form() {
  const [color, setColor] = useState("#aabbcc");
  let name=getFormat(color);
  return (
    <div className='grid-container'>
    <div className="Box mx-2 my-2"></div>
    <div className="Box mx-2 my-2">
      <div className="form-floating mb-3 mx-2 my-2">
        <textarea
          className="form-control"
          placeholder="Leave a text here"
          id="floatingTextarea"
        ></textarea>
        <label htmlFor="floatingTextarea">Box 1 Text</label>
      </div>
      <div className="accordion mb-2 mx-2" id="accordionExample">
        <div className="accordion-item">
          <h2 className="accordion-header" id="headingOne">
            <button
              className="accordion-button"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#collapseOne"
              aria-expanded="true"
              aria-controls="collapseOne"
            >
              Additional Optional Input
            </button>
          </h2>
          <div
            id="collapseOne"
            className="accordion-collapse collapse show"
            aria-labelledby="headingOne"
            data-bs-parent="#accordionExample"
          >
            <div className="accordion-body">
            <div class="row mb-3">
            <label htmlFor="customRange1" class="col-sm-2 col-form-label">FontSize</label>
            <div class="col-sm-10">
            <input type="range" class="form-range" id="customRange1"/>
            </div>
            </div>
            <div class='row mb-3'>
            <label class="col-sm-2 col-form-label">Text Color</label>
            <div className='col-sm-4'>
            <HexColorPicker color={color} onChange={setColor} />
            </div>
            </div>
            </div>
          </div>
        </div>
      </div>
      <div className="d-grid gap-2 mx-2">
        <button className="btn btn-primary" type="button">
          Button
        </button>
      </div>
    </div>
    </div>
  );
}
