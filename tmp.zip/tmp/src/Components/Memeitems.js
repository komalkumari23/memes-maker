import React from 'react';

export default function Memeitems (props) {
	return (
		<>
			
			<div className='card memes-card'>
				<img src={props.image} className='card-img-top' alt='...' />
				<div className='card-body text-center'>
					<h5 className='card-title'>{props.title}</h5>
					<p className='card-text'>
						There are {props.boxcount} editable boxes.
					</p>
				</div>
			</div>
			
		</>
	);
}
