import React from 'react';
import Form from './Form';

function Secondpage(){
    return(
        <>
            <Form/>
        </>
    );
}

export default Secondpage;
