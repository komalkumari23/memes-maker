import React,{useEffect, useState} from "react";
import Memeitems from "./Memeitems";

export default function Memes() {
  const [Items, setItems] = useState([]);
  
  const getmemes = async ()=>{
    try{
      let data=await fetch('https://api.imgflip.com/get_memes');
      let parsedData= await data.json();
      setItems(parsedData.data.memes);
      console.log(parsedData.data.memes)
    }
    catch(error){
      alert(error)
    }
  }

  useEffect( ()=>{getmemes()},[])
  

  return (
    <div>
        <div className="text-center my-3">
				<h3>TOP 100 MEMES</h3>
		</div>
      <div className="row mx-4" >
        {Items?.map((item) => {
          return (
            <div className="col-sm-12 col-md-6 col-lg-4 my-4 " key={item.id}>
              <Memeitems image={item.url} title={item.name} boxcount={item.box_count}/>
            </div>
          );
        })}
      </div>
    </div>
  );
}
