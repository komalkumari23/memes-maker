import './App.css';
import Memes from './Components/Memes';
import Navbar from './Components/Navbar';
import Secondpage from './Components/Secondpage'

function App() {
	return (
		<div className='App'>
			<Navbar />
			{/* <Memes/> */}
			<Secondpage/>
		</div>
	);
}

export default App;
